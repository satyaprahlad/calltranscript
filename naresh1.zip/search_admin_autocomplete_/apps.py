from django.apps import AppConfig


class SearchAdminAutocompleteConfig(AppConfig):
    name = 'search_admin_autocomplete_'
